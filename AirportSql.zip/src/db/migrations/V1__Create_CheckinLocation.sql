CREATE TABLE CheckinLocation(
    CheckinLocationID int NOT NULL PRIMARY KEY,
    StationName VARCHAR(30) NOT NULL  
);
