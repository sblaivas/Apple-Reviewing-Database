CREATE TABLE Passenger (
    Passenger_ID int NOT NULL PRIMARY KEY,
    FirstName VARCHAR(30) NOT NULL,
    LastName VARCHAR(30) NOT NULL,
    CheckInLocationID int NOT NULL,
    CheckInDateTime TIMESTAMP NOT NULL,
    FOREIGN KEY (CheckinLocationID) REFERENCES CheckinLocation(CheckinLocationID)
);