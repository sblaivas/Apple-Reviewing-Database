/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package program;
import entity.*;
import java.util.List;
import java.util.Optional;
import java.util.Scanner;
/**
 *
 * @author Gokhan
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    
    private static DAO checkinlocationDAO;
    private static DAO passengerDAO;
    private static int Passenger_ID;
    
    public static void main(String[] args) {
        checkinlocationDAO = new CheckinLocationDAO();
        passengerDAO = new PassengerDAO();
        
       int choice = 3;
       
        while(choice != 9){
            
            
            System.out.println("Option 1: Create a checkin");
            System.out.println("Option 2: update a checkin");
            System.out.println("Option 3: Delete a checkin");
            System.out.println("Option 4: Show a checkin");
            System.out.println("Option 5: Create a passenger");
            System.out.println("Option 6: update a passenger");
            System.out.println("Option 7: Delete a passenger");
            System.out.println("Option 8: Show a passenger");
             System.out.println("Option 9: Exit");
            
            
            if(choice == 1){
                Scanner choiceOneA = new Scanner(System.in);
                System.out.println("Enter checkinid: ");
                int CheckinLocationID = choiceOneA.nextInt();
               
                
          
                
                //Scanner
                Scanner choiceOneB = new Scanner(System.in);
                System.out.println("Enter stationname");
                String StationName = choiceOneB.nextLine();
                 
                addCheckinLocation(CheckinLocationID, StationName);
            }
            else if(choice == 2){
                Scanner choiceOneAA = new Scanner(System.in);
                System.out.println("Enter checkin id to be updated: ");
                int CheckinLocationID = choiceOneAA.nextInt();
                //Scanner
                Scanner choiceTwo = new Scanner(System.in);
                System.out.println("Enter updated station name:  ");
                String StationName = choiceTwo.nextLine();
                
                CheckinLocation checkin = new CheckinLocation(CheckinLocationID, StationName);
       checkinlocationDAO.update(checkin);
                
                System.out.println("A new checkin was updated successfully");
               
                //printCheckinLocation();
                

              
            }
            else if(choice == 3){
               
                //Scanner
                 Scanner choiceThree = new Scanner(System.in);
                System.out.println("Enter checkin to deleted : ");
                int CheckinLocationID = choiceThree.nextInt();
                
               Scanner choiceho = new Scanner(System.in);
                System.out.println("Enter  station name to delete:  ");
                String StationName = choiceho.nextLine();
                
                CheckinLocation checkin = new CheckinLocation(CheckinLocationID, StationName);
       checkinlocationDAO.delete(checkin);
                System.out.println("Checkin was deleted successfully");
//                
            }
            else if(choice == 4){
                printCheckinLocation();
             
            }
            else if(choice == 5){
                
                //Scanner
                 Scanner pid = new Scanner(System.in);
                System.out.println("Enter PassengerID: ");
                int Passenger_ID = pid.nextInt();
                
                
              
                //Scanner
                Scanner firstName = new Scanner(System.in);
                System.out.println("Enter First Name: ");
                String FirstName = firstName.nextLine();
                
        
                //Scanner
                 Scanner lastName = new Scanner(System.in);
                System.out.println("Enter Last Name: ");
                String LastName = lastName.nextLine();
                
               
                //Scanner
                 Scanner checkInLocId = new Scanner(System.in);
                System.out.println("Enter checkin ID: ");
                int CheckInLocationID = checkInLocId.nextInt();
                
                System.out.println("Enter CheckInDateTime");
                //Scanner
                 Scanner checkInDate = new Scanner(System.in);
                System.out.println("Enter checkin date and time: ");
                String CheckInDateTime = checkInDate.nextLine();
                
                addPassenger(Passenger_ID, FirstName, LastName, CheckInLocationID, CheckInDateTime);
            }
             else if(choice == 6){
                Scanner choiceSix = new Scanner(System.in);
                System.out.println("Enter update for passengerID: ");
                int Passenger_ID = choiceSix.nextInt();
                //Scanner
                Scanner choiceSixA = new Scanner(System.in);
                System.out.println("Enter update for First Name: ");
                String FirstName = choiceSixA.nextLine();
                
                Scanner choiceSixAB = new Scanner(System.in);
                System.out.println("Enter update for Last Name: ");
                String LastName = choiceSixAB.nextLine();
                
                Scanner choiceSixC = new Scanner(System.in);
                System.out.println("Enter update for CheckInLocationID: ");
                int CheckInLocationID = choiceSixC.nextInt();
                
                Scanner choiceSixCA = new Scanner(System.in);
                System.out.println("Enter update for CheckInDateTime: ");
                String CheckInDateTime = choiceSixCA.nextLine();
                
              
                Passenger passengers = new Passenger(Passenger_ID, FirstName, LastName,CheckInLocationID, CheckInDateTime );
       passengerDAO.update(passengers);
                
                System.out.println("A new passenger was updated successfully");
            }
            else if(choice == 7){
                
                //Scanner
                Scanner choiceSeven = new Scanner(System.in);
                System.out.println("Enter Passenger ID to be deleted");
                String deletedPassenger = choiceSeven.nextLine();
                delete(Passenger_ID);
            }   
            else if(choice == 8){
                printPassenger();
            }
            else if(choice == 9){
                System.exit(1);
                 
                
                
                
            
            
            
            
            
            
            
        }

//        printCheckinLocation();
//        CheckinLocation checkin;
//        //First task
//        addCheckinLocation(5, "Kiosk 5");
//        addCheckinLocation(6, "Kiosk 6");
//        addCheckinLocation(8, "Kiosk 8");
//        printCheckinLocation();
//        
//        //Second task
//        checkin  = new CheckinLocation(8, "Kiosk 10");
//        checkinlocationDAO.update(checkin);
//        printCheckinLocation();
//        
//         checkin = getCheckinLocation(1);//This checkin does not exist
//        System.out.println(checkin.getCheckinID() + "-" + checkin.getStationName());//This checkin does not exist, it will print non exist
////       
//        printPassenger();
//        Passenger passenger;
////        
////        
////       //third Task
//       addPassenger(123, "Karly", "Obi", 5,"2009-10-19 07:00:48.756" );
//       addPassenger(258,"Alyssa","Wonder", 6, "2009-10-19 07:13:11.234");
//       addPassenger(331,"Andre", "Beck", 8,"2009-10-19 07:28:28.441" );
////       
//        printPassenger();
//        
//        
//       //fourth Task
//        passenger  = new Passenger(331,"Andre","Beck", 8, "2009-10-19 09:35:28.441");
//        passengerDAO.update(passenger);
//        printPassenger();
//        
//        //fifth Task
//        passenger  = new Passenger(331,"Andre","Beck", 9, "2009-10-19 09:30:18.441");
//        passengerDAO.update(passenger);
//        printPassenger();
//        
        
      
      
        }
        
    }
    static void addCheckinLocation(int CheckinLocationID, String StationName) {
        CheckinLocation checkin;
        checkin = new CheckinLocation(CheckinLocationID, StationName);
        checkinlocationDAO.insert(checkin);
    }
    
    static void addPassenger(int Passenger_ID, String FirstName, String LastName, int CheckInLocationID, String CheckInDateTime) {
        Passenger passenger;
        passenger = new Passenger(Passenger_ID, FirstName, LastName, CheckInLocationID, CheckInDateTime);
        passengerDAO.insert(passenger);
    }
    
    static CheckinLocation getCheckinLocation(int CheckinLocationID) {
        Optional<CheckinLocation> checkin = checkinlocationDAO.get(CheckinLocationID);
        return checkin.orElseGet(() -> new CheckinLocation(-1, "Non-exist"));
    }
    
    static Passenger getPassenger(int Passenger_ID) {
        Optional<Passenger> passenger = passengerDAO.get(Passenger_ID);
        return passenger.orElseGet(() -> new Passenger(-1, "Non-exist", "Non-exist", -1, "Non-exist"));
    }
    
    
    static void printCheckinLocation() {
        List<String> headers = checkinlocationDAO.getColumnNames();
        int numberCols = headers.size();
        //Print column names as header
        for (int i = 0; i < numberCols; i++) {
            String header = headers.get(i);
            System.out.printf("%25s", header);
        }
        System.out.println();
        //Print the results
        List<CheckinLocation> checkin = checkinlocationDAO.getAll();
        int numberRows = checkin.size();
        for (int i = 0; i < numberRows; i++) {
            System.out.printf("%25s%25s", checkin.get(i).getCheckinID(), checkin.get(i).getStationName());
            System.out.println();
        }
    }
    
    static void printPassenger() {
        List<String> headers = passengerDAO.getColumnNames();
        int numberCols = headers.size();
        //Print column names as header
        for (int i = 0; i < numberCols; i++) {
            String header = headers.get(i);
            System.out.printf("%25s", header);
        }
        System.out.println();
        //Print the results
        List<Passenger> passenger = passengerDAO.getAll();
        int numberRows = passenger.size();
        for (int i = 0; i < numberRows; i++) {
            System.out.printf("%25s%25s%25s%25s%25s", passenger.get(i).getPassengerID(), passenger.get(i).getFirstName(), passenger.get(i).getLastName(), passenger.get(i).getLocationID(), passenger.get(i).getDateTime());
            System.out.println();
        }
    }

    private static void update(int CheckinLocationID, String StationName) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    private static void delete(int CheckinLocationID) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}
