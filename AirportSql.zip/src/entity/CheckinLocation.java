/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entity;
/**
 *
 * @author Gokhan
 */
public class CheckinLocation 
{
    private int CheckinLocationID;
    private String StationName;
    
    
    public CheckinLocation(int CheckinLocationID, String StationName)
    {
        this.CheckinLocationID = CheckinLocationID;
        this.StationName = StationName;
        
    }

    public int getCheckinID() {
        return CheckinLocationID;
    }

    public String getStationName() {
        return StationName;
    }

 

    @Override
    public String toString() {
        return "CheckinLocationID{" + "ID=" + CheckinLocationID + ", firstName=" + StationName +  '}';
    }
}
