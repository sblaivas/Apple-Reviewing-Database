/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entity;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import core.*;
import java.sql.ResultSet;
import java.sql.PreparedStatement;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
/**
 *
 * @author Gokhan
 */
public class CheckinLocationDAO implements DAO<CheckinLocation>
{   
    public CheckinLocationDAO() {
        
    }
    List<CheckinLocation> checkins;
    /**
     * Get a single check in location entity as a check in location object
     * @param id
     * @return 
     */
    @Override
    public Optional<CheckinLocation> get(int id) {
        DB db = DB.getInstance();
        ResultSet rs = null;
        try {
            String sql = "SELECT * FROM CheckinLocation WHERE CheckinLocationID = ?";
            
            PreparedStatement stmt = db.getPreparedStatement(sql);
            stmt.setInt(1, id);
            rs = stmt.executeQuery();
            CheckinLocation checkin = null;
            while (rs.next()) {
                checkin = new CheckinLocation(rs.getInt("CheckinLocationID"), rs.getString("StationName"));
            }
            return Optional.ofNullable(checkin);
        } catch (SQLException ex) {
            System.err.println(ex.toString());
            return null;
        }
    }
    
    /**
     * Get all checkin entities as a List
     * @return 
     */
    @Override
    public List<CheckinLocation> getAll() {
        DB db = DB.getInstance();
        ResultSet rs = null;
        checkins = new ArrayList<>();
        try {
            String sql = "SELECT * FROM CheckinLocation";
            rs = db.executeQuery(sql);
            CheckinLocation checkin = null;
            while (rs.next()) {
                checkin = new CheckinLocation(rs.getInt("CheckinLocationID"), rs.getString("StationName"));
                checkins.add(checkin);
            }
            return checkins;
        } catch (SQLException ex) {
            System.err.println(ex.toString());
            return null;
        }
    }
    
    /**
     * Insert a checkin object into checkin table
     * @param checkin 
     */
    @Override
    public void insert(CheckinLocation checkin)
    { 
        DB db = DB.getInstance();
        try {
            String sql = "INSERT INTO CheckinLocation(CheckinLocationID, StationName) VALUES (?, ?)";
            PreparedStatement stmt = db.getPreparedStatement(sql);
            stmt.setInt(1, checkin.getCheckinID());
            stmt.setString(2, checkin.getStationName());

            int rowInserted = stmt.executeUpdate();
            if (rowInserted > 0) {
                System.out.println("A new checkin was inserted successfully!");
            }
        } catch (SQLException ex) {
            System.err.println(ex.toString());
        }
    }
    
    /**
     * Update a checkin entity in database if it exists using a checkin object
     * @param checkin
     */
    @Override
    public void update(CheckinLocation checkin) {
        DB db = DB.getInstance();
        try {
            String sql = "UPDATE CheckinLocation SET StationName=? WHERE CheckinLocationID = ?";
            PreparedStatement stmt = db.getPreparedStatement(sql);
            stmt.setInt(2, checkin.getCheckinID());
            stmt.setString(1, checkin.getStationName());
            
            int rowsUpdated = stmt.executeUpdate();
            if (rowsUpdated > 0) {
                System.out.println("An existing checkin was updated successfully!");
            }
        } catch (SQLException ex) {
            System.err.println(ex.toString());
        }
    }
    
    /**
     * Delete a checkin from checkin table if the entity exists
     * @param checkin 
     */
    @Override
    public void delete(CheckinLocation checkin) {
        DB db = DB.getInstance();
        try {
            String sql = "DELETE FROM CheckinLocation WHERE CheckinLocationID = ?";
            PreparedStatement stmt = db.getPreparedStatement(sql);
            stmt.setInt(1, checkin.getCheckinID());
            //stmt.setString(2, checkin.getStationName());
            int rowsDeleted = stmt.executeUpdate();
            if (rowsDeleted > 0) {
                System.out.println("A check in was deleted successfully!");
            }
        } catch (SQLException ex) {
            System.err.println(ex.toString());
        }
    }
    
    /**
     * Get all column names in a list array
     * @return 
     */
    @Override
    public List<String> getColumnNames() {
        DB db = DB.getInstance();
        ResultSet rs = null;
        List<String> headers = new ArrayList<>();
        try {
            String sql = "SELECT * FROM CheckinLocation WHERE CheckinLocationID = -1";//We just need this sql query to get the column headers
            rs = db.executeQuery(sql);
            ResultSetMetaData rsmd = rs.getMetaData();
            //Get number of columns in the result set
            int numberCols = rsmd.getColumnCount();
            for (int i = 1; i <= numberCols; i++) {
                headers.add(rsmd.getColumnLabel(i));//Add column headers to the list
            }
            return headers;
        } catch (SQLException ex) {
            System.err.println(ex.toString());
            return null;
        } 
    }
}
