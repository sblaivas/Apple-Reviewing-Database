/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entity;
/**
 *
 * @author Gokhan
 */
public class Passenger 
{
    private int Passenger_ID;
    private String FirstName;
    private String LastName;
    private int CheckInLocationID;
    private String CheckInDateTime;
    
    public Passenger(int Passenger_ID, String FirstName, String LastName, int CheckInLocationID, String CheckInDateTime)
    {
        this.Passenger_ID = Passenger_ID;
        this.FirstName = FirstName;
        this.LastName = LastName;
        this.CheckInLocationID = CheckInLocationID;
        this.CheckInDateTime = CheckInDateTime;
    }

    public int getPassengerID() {
        return Passenger_ID;
    }

    public String getFirstName() {
        return FirstName;
    }

    public String getLastName() {
        return LastName;
    }

    public int getLocationID() {
        return CheckInLocationID;
    }
    
    public String getDateTime() {
        return CheckInDateTime;
    }

    @Override
    public String toString() {
        return "Passenger{" + "Passenger_ID=" + Passenger_ID + ", FirstName=" + FirstName + ", LastName=" + LastName + ", CheckInLocationID=" + CheckInLocationID + ", CheckInDateTime=" + CheckInDateTime + '}';
    }
}
